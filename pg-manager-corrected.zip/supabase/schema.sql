-- PG Manager starter schema for Supabase/PostgreSQL.
-- This file is not connected to the browser app yet. Review before running.
create extension if not exists pgcrypto;

create table if not exists public.owner_profiles (
  user_id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null default '',
  created_at timestamptz not null default now()
);
create table if not exists public.properties (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references auth.users(id) on delete cascade,
  name text not null,
  address text not null default '',
  electricity_rate numeric(12,2) not null default 0 check (electricity_rate >= 0),
  created_at timestamptz not null default now(),
  unique(owner_id, name)
);
create table if not exists public.rooms (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references auth.users(id) on delete cascade,
  property_id uuid not null references public.properties(id) on delete cascade,
  room_number text not null,
  capacity integer not null default 1 check (capacity > 0),
  monthly_rent numeric(12,2) not null default 0 check (monthly_rent >= 0),
  unique(property_id, room_number)
);
create table if not exists public.tenants (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references auth.users(id) on delete cascade,
  property_id uuid not null references public.properties(id) on delete cascade,
  room_id uuid references public.rooms(id) on delete set null,
  full_name text not null,
  phone text not null default '',
  email text not null default '',
  move_in_date date,
  move_out_date date,
  status text not null default 'active' check (status in ('active','inactive')),
  created_at timestamptz not null default now()
);
create table if not exists public.invoices (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references auth.users(id) on delete cascade,
  property_id uuid not null references public.properties(id) on delete cascade,
  tenant_id uuid not null references public.tenants(id) on delete restrict,
  billing_month date not null,
  rent_amount numeric(12,2) not null default 0 check (rent_amount >= 0),
  electricity_previous numeric(12,3) not null default 0 check (electricity_previous >= 0),
  electricity_current numeric(12,3) not null default 0 check (electricity_current >= electricity_previous),
  electricity_rate numeric(12,2) not null default 0 check (electricity_rate >= 0),
  other_charges numeric(12,2) not null default 0 check (other_charges >= 0),
  total_amount numeric(12,2) not null check (total_amount >= 0),
  status text not null default 'unpaid' check (status in ('unpaid','partial','paid','void')),
  due_date date,
  created_at timestamptz not null default now(),
  unique(tenant_id, billing_month)
);
create table if not exists public.payments (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references auth.users(id) on delete cascade,
  invoice_id uuid not null references public.invoices(id) on delete restrict,
  amount numeric(12,2) not null check (amount > 0),
  payment_method text not null default 'cash',
  reference_number text not null default '',
  received_at timestamptz not null default now(),
  notes text not null default ''
);

create index if not exists properties_owner_idx on public.properties(owner_id);
create index if not exists rooms_owner_property_idx on public.rooms(owner_id, property_id);
create index if not exists tenants_owner_property_idx on public.tenants(owner_id, property_id);
create index if not exists invoices_owner_month_idx on public.invoices(owner_id, billing_month);
create index if not exists payments_owner_received_idx on public.payments(owner_id, received_at);

alter table public.owner_profiles enable row level security;
alter table public.properties enable row level security;
alter table public.rooms enable row level security;
alter table public.tenants enable row level security;
alter table public.invoices enable row level security;
alter table public.payments enable row level security;

drop policy if exists "Owner profile access" on public.owner_profiles;
create policy "Owner profile access" on public.owner_profiles for all using (user_id = auth.uid()) with check (user_id = auth.uid());
drop policy if exists "Owner properties access" on public.properties;
create policy "Owner properties access" on public.properties for all using (owner_id = auth.uid()) with check (owner_id = auth.uid());
drop policy if exists "Owner rooms access" on public.rooms;
create policy "Owner rooms access" on public.rooms for all using (owner_id = auth.uid()) with check (owner_id = auth.uid());
drop policy if exists "Owner tenants access" on public.tenants;
create policy "Owner tenants access" on public.tenants for all using (owner_id = auth.uid()) with check (owner_id = auth.uid());
drop policy if exists "Owner invoices access" on public.invoices;
create policy "Owner invoices access" on public.invoices for all using (owner_id = auth.uid()) with check (owner_id = auth.uid());
drop policy if exists "Owner payments access" on public.payments;
create policy "Owner payments access" on public.payments for all using (owner_id = auth.uid()) with check (owner_id = auth.uid());
