# PG Manager — corrected starter

Mobile-friendly PG rent and electricity manager using plain HTML, CSS and JavaScript.

## Files
- `index.html` — application and browser-side logic
- `sw.js` — service worker for app-shell/offline navigation
- `manifest.json` — PWA metadata
- `icon-192.png`, `icon-512.png` — app icons
- `supabase/schema.sql` — starter database schema for the future cloud-upgrade phase
- `DEPLOYMENT.md` — Vercel deployment checklist

## Deploy on Vercel
- Framework Preset: Other
- Root Directory: `./`
- Build Command: leave blank
- Output Directory: `.`
- Install Command: leave blank

All files must be in the repository root except `supabase/schema.sql`.

## Existing features preserved
Tenant add/edit/delete/search; pending/paid/all views; rent and electricity calculation; meter readings; payment confirmation and undo; WhatsApp reminders; sample data; JSON backup export/import; settings; PWA manifest.

## Improvements in this version
- Corrected invalid CSS font shorthand declarations.
- Improved service-worker fallback: only navigation requests fall back to the cached homepage.
- Added a per-tenant payment history ledger for payments recorded after installing this version.
- Strengthened rent, meter, payment and electricity-rate validation.
- Prevented duplicate room numbers in this single-property browser version.
- Improved JSON backup validation and added schema/export metadata.
- Preserved compatibility with older backups that do not contain payment history.

## Data and security limitations
This version still stores operational data in this browser's `localStorage`. It does not yet provide cloud sync, owner login, staff accounts or tenant accounts. Browser data can be cleared. Export a JSON backup regularly and verify it opens. Payment history begins recording from the date this version is used; old payments cannot be recreated unless they are in a backup.

## Next phase: Supabase
`supabase/schema.sql` is a starter PostgreSQL schema with row-level security for owner-isolated records. It is not connected to the app yet. Cloud sync and login require a Supabase project, Auth configuration, frontend integration and end-to-end testing. Never put a Supabase service-role key in browser code. Use only a publishable/anon key with tested RLS policies.

## Backup
Use Settings → Export weekly. Store the file in two safe locations and test restore using a copy in a separate browser profile.
